package com.liferay.registration.constants;

/**
 * @author Prashant Jha
 */
public class RegistrationPortletKeys {

	public static final String REGISTRATION =
		"com_liferay_registration_RegistrationPortlet";

}