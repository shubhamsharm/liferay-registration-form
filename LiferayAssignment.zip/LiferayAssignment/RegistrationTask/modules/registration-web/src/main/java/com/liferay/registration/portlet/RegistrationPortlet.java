package com.liferay.registration.portlet;

import com.liferay.counter.kernel.service.CounterLocalServiceUtil;
import com.liferay.portal.kernel.portlet.bridges.mvc.MVCPortlet;
import com.liferay.portal.kernel.util.ParamUtil;
import com.liferay.registration.constants.RegistrationPortletKeys;
import com.liferay.service.registration.model.RegistrationForm;
import com.liferay.service.registration.service.RegistrationFormLocalServiceUtil;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.Portlet;
import javax.portlet.PortletException;

import org.osgi.service.component.annotations.Component;

/**
 * @author Prashant Jha
 */
@Component(
	immediate = true,
	property = {
		"com.liferay.portlet.display-category=category.sample",
		"com.liferay.portlet.header-portlet-css=/css/main.css",
		"com.liferay.portlet.instanceable=true",
		"javax.portlet.display-name=Registration",
		"javax.portlet.init-param.template-path=/",
		"javax.portlet.init-param.view-template=/view.jsp",
		"javax.portlet.name=" + RegistrationPortletKeys.REGISTRATION,
		"javax.portlet.resource-bundle=content.Language",
		"javax.portlet.security-role-ref=power-user,user"
	},
	service = Portlet.class
)
public class RegistrationPortlet extends MVCPortlet {
	
public void regfrmSubmit(ActionRequest request, ActionResponse response) throws IOException,PortletException {
		
		String first_name = ParamUtil.getString(request,"first_name");
		String last_name = ParamUtil.getString(request,"last_name");
		String email_address = ParamUtil.getString(request,"email_address");
		String username = ParamUtil.getString(request,"username");
		String gender = ParamUtil.getString(request,"gender");
		String birthday = ParamUtil.getString(request,"birthday");
		String password1 = ParamUtil.getString(request,"password1");
		String password2 = ParamUtil.getString(request,"password2");
		String home_phone = ParamUtil.getString(request,"home_phone");
		String mobile_phone = ParamUtil.getString(request,"mobile_phone");
		String address1 = ParamUtil.getString(request,"address1");
		String address2 = ParamUtil.getString(request,"address2");
		String city = ParamUtil.getString(request,"city");
		String state = ParamUtil.getString(request,"state");
		String zip = ParamUtil.getString(request,"zip");
		String security_question = ParamUtil.getString(request,"security_question");
		String security_answer = ParamUtil.getString(request,"security_answer");
		
		//System.out.print(zip);
		try {
		RegistrationForm registrationForm = RegistrationFormLocalServiceUtil.createRegistrationForm(CounterLocalServiceUtil.increment());
		registrationForm.setFirst_name(first_name);
		registrationForm.setLast_name(last_name);
		registrationForm.setEmail_address(email_address);
		registrationForm.setUsername(username);
		registrationForm.setGender(gender);
		registrationForm.setBirthday(birthday);
		registrationForm.setPassword1(password1);
		registrationForm.setPassword2(password2);
		registrationForm.setHome_phone(home_phone);
		registrationForm.setMobile_phone(mobile_phone);
		registrationForm.setAddress1(address1);
		registrationForm.setAddress2(address2);
		registrationForm.setCity(city);
		registrationForm.setState(state);
		registrationForm.setZip(zip);
		registrationForm.setSecurity_question(security_question);
		registrationForm.setSecurity_answer(security_answer);
		
		RegistrationFormLocalServiceUtil.addRegistrationForm(registrationForm);
		
		System.out.print("Successfully Added..");
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
}