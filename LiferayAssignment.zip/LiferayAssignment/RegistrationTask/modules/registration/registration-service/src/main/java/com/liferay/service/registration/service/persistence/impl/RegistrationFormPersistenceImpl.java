/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.service.persistence.impl;

import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.configuration.Configuration;
import com.liferay.portal.kernel.dao.orm.ArgumentsResolver;
import com.liferay.portal.kernel.dao.orm.EntityCache;
import com.liferay.portal.kernel.dao.orm.FinderCache;
import com.liferay.portal.kernel.dao.orm.FinderPath;
import com.liferay.portal.kernel.dao.orm.Query;
import com.liferay.portal.kernel.dao.orm.QueryUtil;
import com.liferay.portal.kernel.dao.orm.Session;
import com.liferay.portal.kernel.dao.orm.SessionFactory;
import com.liferay.portal.kernel.log.Log;
import com.liferay.portal.kernel.log.LogFactoryUtil;
import com.liferay.portal.kernel.model.BaseModel;
import com.liferay.portal.kernel.service.persistence.impl.BasePersistenceImpl;
import com.liferay.portal.kernel.util.GetterUtil;
import com.liferay.portal.kernel.util.MapUtil;
import com.liferay.portal.kernel.util.OrderByComparator;
import com.liferay.portal.kernel.util.PropsKeys;
import com.liferay.portal.kernel.util.PropsUtil;
import com.liferay.portal.kernel.util.SetUtil;
import com.liferay.service.registration.exception.NoSuchRegistrationFormException;
import com.liferay.service.registration.model.RegistrationForm;
import com.liferay.service.registration.model.impl.RegistrationFormImpl;
import com.liferay.service.registration.model.impl.RegistrationFormModelImpl;
import com.liferay.service.registration.service.persistence.RegistrationFormPersistence;
import com.liferay.service.registration.service.persistence.RegistrationFormUtil;
import com.liferay.service.registration.service.persistence.impl.constants.RegistrationFormPersistenceConstants;

import java.io.Serializable;

import java.lang.reflect.Field;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.sql.DataSource;

import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceRegistration;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Reference;

/**
 * The persistence implementation for the registration form service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
@Component(service = RegistrationFormPersistence.class)
public class RegistrationFormPersistenceImpl
	extends BasePersistenceImpl<RegistrationForm>
	implements RegistrationFormPersistence {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this class directly. Always use <code>RegistrationFormUtil</code> to access the registration form persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this class.
	 */
	public static final String FINDER_CLASS_NAME_ENTITY =
		RegistrationFormImpl.class.getName();

	public static final String FINDER_CLASS_NAME_LIST_WITH_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List1";

	public static final String FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION =
		FINDER_CLASS_NAME_ENTITY + ".List2";

	private FinderPath _finderPathWithPaginationFindAll;
	private FinderPath _finderPathWithoutPaginationFindAll;
	private FinderPath _finderPathCountAll;

	public RegistrationFormPersistenceImpl() {
		Map<String, String> dbColumnNames = new HashMap<String, String>();

		dbColumnNames.put("state", "state_");

		setDBColumnNames(dbColumnNames);

		setModelClass(RegistrationForm.class);

		setModelImplClass(RegistrationFormImpl.class);
		setModelPKClass(long.class);
	}

	/**
	 * Caches the registration form in the entity cache if it is enabled.
	 *
	 * @param registrationForm the registration form
	 */
	@Override
	public void cacheResult(RegistrationForm registrationForm) {
		entityCache.putResult(
			RegistrationFormImpl.class, registrationForm.getPrimaryKey(),
			registrationForm);
	}

	private int _valueObjectFinderCacheListThreshold;

	/**
	 * Caches the registration forms in the entity cache if it is enabled.
	 *
	 * @param registrationForms the registration forms
	 */
	@Override
	public void cacheResult(List<RegistrationForm> registrationForms) {
		if ((_valueObjectFinderCacheListThreshold == 0) ||
			((_valueObjectFinderCacheListThreshold > 0) &&
			 (registrationForms.size() >
				 _valueObjectFinderCacheListThreshold))) {

			return;
		}

		for (RegistrationForm registrationForm : registrationForms) {
			if (entityCache.getResult(
					RegistrationFormImpl.class,
					registrationForm.getPrimaryKey()) == null) {

				cacheResult(registrationForm);
			}
		}
	}

	/**
	 * Clears the cache for all registration forms.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache() {
		entityCache.clearCache(RegistrationFormImpl.class);

		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);
	}

	/**
	 * Clears the cache for the registration form.
	 *
	 * <p>
	 * The <code>EntityCache</code> and <code>FinderCache</code> are both cleared by this method.
	 * </p>
	 */
	@Override
	public void clearCache(RegistrationForm registrationForm) {
		entityCache.removeResult(RegistrationFormImpl.class, registrationForm);
	}

	@Override
	public void clearCache(List<RegistrationForm> registrationForms) {
		for (RegistrationForm registrationForm : registrationForms) {
			entityCache.removeResult(
				RegistrationFormImpl.class, registrationForm);
		}
	}

	@Override
	public void clearCache(Set<Serializable> primaryKeys) {
		finderCache.clearCache(FINDER_CLASS_NAME_ENTITY);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITH_PAGINATION);
		finderCache.clearCache(FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION);

		for (Serializable primaryKey : primaryKeys) {
			entityCache.removeResult(RegistrationFormImpl.class, primaryKey);
		}
	}

	/**
	 * Creates a new registration form with the primary key. Does not add the registration form to the database.
	 *
	 * @param regId the primary key for the new registration form
	 * @return the new registration form
	 */
	@Override
	public RegistrationForm create(long regId) {
		RegistrationForm registrationForm = new RegistrationFormImpl();

		registrationForm.setNew(true);
		registrationForm.setPrimaryKey(regId);

		return registrationForm;
	}

	/**
	 * Removes the registration form with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form that was removed
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	@Override
	public RegistrationForm remove(long regId)
		throws NoSuchRegistrationFormException {

		return remove((Serializable)regId);
	}

	/**
	 * Removes the registration form with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param primaryKey the primary key of the registration form
	 * @return the registration form that was removed
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	@Override
	public RegistrationForm remove(Serializable primaryKey)
		throws NoSuchRegistrationFormException {

		Session session = null;

		try {
			session = openSession();

			RegistrationForm registrationForm = (RegistrationForm)session.get(
				RegistrationFormImpl.class, primaryKey);

			if (registrationForm == null) {
				if (_log.isDebugEnabled()) {
					_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
				}

				throw new NoSuchRegistrationFormException(
					_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			return remove(registrationForm);
		}
		catch (NoSuchRegistrationFormException noSuchEntityException) {
			throw noSuchEntityException;
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}
	}

	@Override
	protected RegistrationForm removeImpl(RegistrationForm registrationForm) {
		Session session = null;

		try {
			session = openSession();

			if (!session.contains(registrationForm)) {
				registrationForm = (RegistrationForm)session.get(
					RegistrationFormImpl.class,
					registrationForm.getPrimaryKeyObj());
			}

			if (registrationForm != null) {
				session.delete(registrationForm);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		if (registrationForm != null) {
			clearCache(registrationForm);
		}

		return registrationForm;
	}

	@Override
	public RegistrationForm updateImpl(RegistrationForm registrationForm) {
		boolean isNew = registrationForm.isNew();

		Session session = null;

		try {
			session = openSession();

			if (isNew) {
				session.save(registrationForm);
			}
			else {
				registrationForm = (RegistrationForm)session.merge(
					registrationForm);
			}
		}
		catch (Exception exception) {
			throw processException(exception);
		}
		finally {
			closeSession(session);
		}

		entityCache.putResult(
			RegistrationFormImpl.class, registrationForm, false, true);

		if (isNew) {
			registrationForm.setNew(false);
		}

		registrationForm.resetOriginalValues();

		return registrationForm;
	}

	/**
	 * Returns the registration form with the primary key or throws a <code>com.liferay.portal.kernel.exception.NoSuchModelException</code> if it could not be found.
	 *
	 * @param primaryKey the primary key of the registration form
	 * @return the registration form
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	@Override
	public RegistrationForm findByPrimaryKey(Serializable primaryKey)
		throws NoSuchRegistrationFormException {

		RegistrationForm registrationForm = fetchByPrimaryKey(primaryKey);

		if (registrationForm == null) {
			if (_log.isDebugEnabled()) {
				_log.debug(_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
			}

			throw new NoSuchRegistrationFormException(
				_NO_SUCH_ENTITY_WITH_PRIMARY_KEY + primaryKey);
		}

		return registrationForm;
	}

	/**
	 * Returns the registration form with the primary key or throws a <code>NoSuchRegistrationFormException</code> if it could not be found.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	@Override
	public RegistrationForm findByPrimaryKey(long regId)
		throws NoSuchRegistrationFormException {

		return findByPrimaryKey((Serializable)regId);
	}

	/**
	 * Returns the registration form with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form, or <code>null</code> if a registration form with the primary key could not be found
	 */
	@Override
	public RegistrationForm fetchByPrimaryKey(long regId) {
		return fetchByPrimaryKey((Serializable)regId);
	}

	/**
	 * Returns all the registration forms.
	 *
	 * @return the registration forms
	 */
	@Override
	public List<RegistrationForm> findAll() {
		return findAll(QueryUtil.ALL_POS, QueryUtil.ALL_POS, null);
	}

	/**
	 * Returns a range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @return the range of registration forms
	 */
	@Override
	public List<RegistrationForm> findAll(int start, int end) {
		return findAll(start, end, null);
	}

	/**
	 * Returns an ordered range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of registration forms
	 */
	@Override
	public List<RegistrationForm> findAll(
		int start, int end,
		OrderByComparator<RegistrationForm> orderByComparator) {

		return findAll(start, end, orderByComparator, true);
	}

	/**
	 * Returns an ordered range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of registration forms
	 */
	@Override
	public List<RegistrationForm> findAll(
		int start, int end,
		OrderByComparator<RegistrationForm> orderByComparator,
		boolean useFinderCache) {

		FinderPath finderPath = null;
		Object[] finderArgs = null;

		if ((start == QueryUtil.ALL_POS) && (end == QueryUtil.ALL_POS) &&
			(orderByComparator == null)) {

			if (useFinderCache) {
				finderPath = _finderPathWithoutPaginationFindAll;
				finderArgs = FINDER_ARGS_EMPTY;
			}
		}
		else if (useFinderCache) {
			finderPath = _finderPathWithPaginationFindAll;
			finderArgs = new Object[] {start, end, orderByComparator};
		}

		List<RegistrationForm> list = null;

		if (useFinderCache) {
			list = (List<RegistrationForm>)finderCache.getResult(
				finderPath, finderArgs, this);
		}

		if (list == null) {
			StringBundler sb = null;
			String sql = null;

			if (orderByComparator != null) {
				sb = new StringBundler(
					2 + (orderByComparator.getOrderByFields().length * 2));

				sb.append(_SQL_SELECT_REGISTRATIONFORM);

				appendOrderByComparator(
					sb, _ORDER_BY_ENTITY_ALIAS, orderByComparator);

				sql = sb.toString();
			}
			else {
				sql = _SQL_SELECT_REGISTRATIONFORM;

				sql = sql.concat(RegistrationFormModelImpl.ORDER_BY_JPQL);
			}

			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(sql);

				list = (List<RegistrationForm>)QueryUtil.list(
					query, getDialect(), start, end);

				cacheResult(list);

				if (useFinderCache) {
					finderCache.putResult(finderPath, finderArgs, list);
				}
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return list;
	}

	/**
	 * Removes all the registration forms from the database.
	 *
	 */
	@Override
	public void removeAll() {
		for (RegistrationForm registrationForm : findAll()) {
			remove(registrationForm);
		}
	}

	/**
	 * Returns the number of registration forms.
	 *
	 * @return the number of registration forms
	 */
	@Override
	public int countAll() {
		Long count = (Long)finderCache.getResult(
			_finderPathCountAll, FINDER_ARGS_EMPTY, this);

		if (count == null) {
			Session session = null;

			try {
				session = openSession();

				Query query = session.createQuery(_SQL_COUNT_REGISTRATIONFORM);

				count = (Long)query.uniqueResult();

				finderCache.putResult(
					_finderPathCountAll, FINDER_ARGS_EMPTY, count);
			}
			catch (Exception exception) {
				throw processException(exception);
			}
			finally {
				closeSession(session);
			}
		}

		return count.intValue();
	}

	@Override
	public Set<String> getBadColumnNames() {
		return _badColumnNames;
	}

	@Override
	protected EntityCache getEntityCache() {
		return entityCache;
	}

	@Override
	protected String getPKDBName() {
		return "regId";
	}

	@Override
	protected String getSelectSQL() {
		return _SQL_SELECT_REGISTRATIONFORM;
	}

	@Override
	protected Map<String, Integer> getTableColumnsMap() {
		return RegistrationFormModelImpl.TABLE_COLUMNS_MAP;
	}

	/**
	 * Initializes the registration form persistence.
	 */
	@Activate
	public void activate(BundleContext bundleContext) {
		_bundleContext = bundleContext;

		_argumentsResolverServiceRegistration = _bundleContext.registerService(
			ArgumentsResolver.class,
			new RegistrationFormModelArgumentsResolver(),
			MapUtil.singletonDictionary(
				"model.class.name", RegistrationForm.class.getName()));

		_valueObjectFinderCacheListThreshold = GetterUtil.getInteger(
			PropsUtil.get(PropsKeys.VALUE_OBJECT_FINDER_CACHE_LIST_THRESHOLD));

		_finderPathWithPaginationFindAll = _createFinderPath(
			FINDER_CLASS_NAME_LIST_WITH_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathWithoutPaginationFindAll = _createFinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "findAll", new String[0],
			new String[0], true);

		_finderPathCountAll = _createFinderPath(
			FINDER_CLASS_NAME_LIST_WITHOUT_PAGINATION, "countAll",
			new String[0], new String[0], false);

		_setRegistrationFormUtilPersistence(this);
	}

	@Deactivate
	public void deactivate() {
		_setRegistrationFormUtilPersistence(null);

		entityCache.removeCache(RegistrationFormImpl.class.getName());

		_argumentsResolverServiceRegistration.unregister();

		for (ServiceRegistration<FinderPath> serviceRegistration :
				_serviceRegistrations) {

			serviceRegistration.unregister();
		}
	}

	private void _setRegistrationFormUtilPersistence(
		RegistrationFormPersistence registrationFormPersistence) {

		try {
			Field field = RegistrationFormUtil.class.getDeclaredField(
				"_persistence");

			field.setAccessible(true);

			field.set(null, registrationFormPersistence);
		}
		catch (ReflectiveOperationException reflectiveOperationException) {
			throw new RuntimeException(reflectiveOperationException);
		}
	}

	@Override
	@Reference(
		target = RegistrationFormPersistenceConstants.SERVICE_CONFIGURATION_FILTER,
		unbind = "-"
	)
	public void setConfiguration(Configuration configuration) {
	}

	@Override
	@Reference(
		target = RegistrationFormPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setDataSource(DataSource dataSource) {
		super.setDataSource(dataSource);
	}

	@Override
	@Reference(
		target = RegistrationFormPersistenceConstants.ORIGIN_BUNDLE_SYMBOLIC_NAME_FILTER,
		unbind = "-"
	)
	public void setSessionFactory(SessionFactory sessionFactory) {
		super.setSessionFactory(sessionFactory);
	}

	private BundleContext _bundleContext;

	@Reference
	protected EntityCache entityCache;

	@Reference
	protected FinderCache finderCache;

	private static final String _SQL_SELECT_REGISTRATIONFORM =
		"SELECT registrationForm FROM RegistrationForm registrationForm";

	private static final String _SQL_COUNT_REGISTRATIONFORM =
		"SELECT COUNT(registrationForm) FROM RegistrationForm registrationForm";

	private static final String _ORDER_BY_ENTITY_ALIAS = "registrationForm.";

	private static final String _NO_SUCH_ENTITY_WITH_PRIMARY_KEY =
		"No RegistrationForm exists with the primary key ";

	private static final Log _log = LogFactoryUtil.getLog(
		RegistrationFormPersistenceImpl.class);

	private static final Set<String> _badColumnNames = SetUtil.fromArray(
		new String[] {"state"});

	private FinderPath _createFinderPath(
		String cacheName, String methodName, String[] params,
		String[] columnNames, boolean baseModelResult) {

		FinderPath finderPath = new FinderPath(
			cacheName, methodName, params, columnNames, baseModelResult);

		if (!cacheName.equals(FINDER_CLASS_NAME_LIST_WITH_PAGINATION)) {
			_serviceRegistrations.add(
				_bundleContext.registerService(
					FinderPath.class, finderPath,
					MapUtil.singletonDictionary("cache.name", cacheName)));
		}

		return finderPath;
	}

	private Set<ServiceRegistration<FinderPath>> _serviceRegistrations =
		new HashSet<>();
	private ServiceRegistration<ArgumentsResolver>
		_argumentsResolverServiceRegistration;

	private static class RegistrationFormModelArgumentsResolver
		implements ArgumentsResolver {

		@Override
		public Object[] getArguments(
			FinderPath finderPath, BaseModel<?> baseModel, boolean checkColumn,
			boolean original) {

			String[] columnNames = finderPath.getColumnNames();

			if ((columnNames == null) || (columnNames.length == 0)) {
				if (baseModel.isNew()) {
					return new Object[0];
				}

				return null;
			}

			RegistrationFormModelImpl registrationFormModelImpl =
				(RegistrationFormModelImpl)baseModel;

			long columnBitmask = registrationFormModelImpl.getColumnBitmask();

			if (!checkColumn || (columnBitmask == 0)) {
				return _getValue(
					registrationFormModelImpl, columnNames, original);
			}

			Long finderPathColumnBitmask = _finderPathColumnBitmasksCache.get(
				finderPath);

			if (finderPathColumnBitmask == null) {
				finderPathColumnBitmask = 0L;

				for (String columnName : columnNames) {
					finderPathColumnBitmask |=
						registrationFormModelImpl.getColumnBitmask(columnName);
				}

				_finderPathColumnBitmasksCache.put(
					finderPath, finderPathColumnBitmask);
			}

			if ((columnBitmask & finderPathColumnBitmask) != 0) {
				return _getValue(
					registrationFormModelImpl, columnNames, original);
			}

			return null;
		}

		private static Object[] _getValue(
			RegistrationFormModelImpl registrationFormModelImpl,
			String[] columnNames, boolean original) {

			Object[] arguments = new Object[columnNames.length];

			for (int i = 0; i < arguments.length; i++) {
				String columnName = columnNames[i];

				if (original) {
					arguments[i] =
						registrationFormModelImpl.getColumnOriginalValue(
							columnName);
				}
				else {
					arguments[i] = registrationFormModelImpl.getColumnValue(
						columnName);
				}
			}

			return arguments;
		}

		private static final Map<FinderPath, Long>
			_finderPathColumnBitmasksCache = new ConcurrentHashMap<>();

	}

}