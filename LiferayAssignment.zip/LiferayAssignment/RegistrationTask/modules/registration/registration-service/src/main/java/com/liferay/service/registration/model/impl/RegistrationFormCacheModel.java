/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.model.impl;

import com.liferay.petra.lang.HashUtil;
import com.liferay.petra.string.StringBundler;
import com.liferay.portal.kernel.model.CacheModel;
import com.liferay.service.registration.model.RegistrationForm;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 * The cache model class for representing RegistrationForm in entity cache.
 *
 * @author Brian Wing Shun Chan
 * @generated
 */
public class RegistrationFormCacheModel
	implements CacheModel<RegistrationForm>, Externalizable {

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}

		if (!(object instanceof RegistrationFormCacheModel)) {
			return false;
		}

		RegistrationFormCacheModel registrationFormCacheModel =
			(RegistrationFormCacheModel)object;

		if (regId == registrationFormCacheModel.regId) {
			return true;
		}

		return false;
	}

	@Override
	public int hashCode() {
		return HashUtil.hash(0, regId);
	}

	@Override
	public String toString() {
		StringBundler sb = new StringBundler(37);

		sb.append("{regId=");
		sb.append(regId);
		sb.append(", first_name=");
		sb.append(first_name);
		sb.append(", last_name=");
		sb.append(last_name);
		sb.append(", email_address=");
		sb.append(email_address);
		sb.append(", username=");
		sb.append(username);
		sb.append(", gender=");
		sb.append(gender);
		sb.append(", birthday=");
		sb.append(birthday);
		sb.append(", password1=");
		sb.append(password1);
		sb.append(", password2=");
		sb.append(password2);
		sb.append(", home_phone=");
		sb.append(home_phone);
		sb.append(", mobile_phone=");
		sb.append(mobile_phone);
		sb.append(", address1=");
		sb.append(address1);
		sb.append(", address2=");
		sb.append(address2);
		sb.append(", city=");
		sb.append(city);
		sb.append(", state=");
		sb.append(state);
		sb.append(", zip=");
		sb.append(zip);
		sb.append(", security_question=");
		sb.append(security_question);
		sb.append(", security_answer=");
		sb.append(security_answer);
		sb.append("}");

		return sb.toString();
	}

	@Override
	public RegistrationForm toEntityModel() {
		RegistrationFormImpl registrationFormImpl = new RegistrationFormImpl();

		registrationFormImpl.setRegId(regId);

		if (first_name == null) {
			registrationFormImpl.setFirst_name("");
		}
		else {
			registrationFormImpl.setFirst_name(first_name);
		}

		if (last_name == null) {
			registrationFormImpl.setLast_name("");
		}
		else {
			registrationFormImpl.setLast_name(last_name);
		}

		if (email_address == null) {
			registrationFormImpl.setEmail_address("");
		}
		else {
			registrationFormImpl.setEmail_address(email_address);
		}

		if (username == null) {
			registrationFormImpl.setUsername("");
		}
		else {
			registrationFormImpl.setUsername(username);
		}

		if (gender == null) {
			registrationFormImpl.setGender("");
		}
		else {
			registrationFormImpl.setGender(gender);
		}

		if (birthday == null) {
			registrationFormImpl.setBirthday("");
		}
		else {
			registrationFormImpl.setBirthday(birthday);
		}

		if (password1 == null) {
			registrationFormImpl.setPassword1("");
		}
		else {
			registrationFormImpl.setPassword1(password1);
		}

		if (password2 == null) {
			registrationFormImpl.setPassword2("");
		}
		else {
			registrationFormImpl.setPassword2(password2);
		}

		if (home_phone == null) {
			registrationFormImpl.setHome_phone("");
		}
		else {
			registrationFormImpl.setHome_phone(home_phone);
		}

		if (mobile_phone == null) {
			registrationFormImpl.setMobile_phone("");
		}
		else {
			registrationFormImpl.setMobile_phone(mobile_phone);
		}

		if (address1 == null) {
			registrationFormImpl.setAddress1("");
		}
		else {
			registrationFormImpl.setAddress1(address1);
		}

		if (address2 == null) {
			registrationFormImpl.setAddress2("");
		}
		else {
			registrationFormImpl.setAddress2(address2);
		}

		if (city == null) {
			registrationFormImpl.setCity("");
		}
		else {
			registrationFormImpl.setCity(city);
		}

		if (state == null) {
			registrationFormImpl.setState("");
		}
		else {
			registrationFormImpl.setState(state);
		}

		if (zip == null) {
			registrationFormImpl.setZip("");
		}
		else {
			registrationFormImpl.setZip(zip);
		}

		if (security_question == null) {
			registrationFormImpl.setSecurity_question("");
		}
		else {
			registrationFormImpl.setSecurity_question(security_question);
		}

		if (security_answer == null) {
			registrationFormImpl.setSecurity_answer("");
		}
		else {
			registrationFormImpl.setSecurity_answer(security_answer);
		}

		registrationFormImpl.resetOriginalValues();

		return registrationFormImpl;
	}

	@Override
	public void readExternal(ObjectInput objectInput) throws IOException {
		regId = objectInput.readLong();
		first_name = objectInput.readUTF();
		last_name = objectInput.readUTF();
		email_address = objectInput.readUTF();
		username = objectInput.readUTF();
		gender = objectInput.readUTF();
		birthday = objectInput.readUTF();
		password1 = objectInput.readUTF();
		password2 = objectInput.readUTF();
		home_phone = objectInput.readUTF();
		mobile_phone = objectInput.readUTF();
		address1 = objectInput.readUTF();
		address2 = objectInput.readUTF();
		city = objectInput.readUTF();
		state = objectInput.readUTF();
		zip = objectInput.readUTF();
		security_question = objectInput.readUTF();
		security_answer = objectInput.readUTF();
	}

	@Override
	public void writeExternal(ObjectOutput objectOutput) throws IOException {
		objectOutput.writeLong(regId);

		if (first_name == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(first_name);
		}

		if (last_name == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(last_name);
		}

		if (email_address == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(email_address);
		}

		if (username == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(username);
		}

		if (gender == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(gender);
		}

		if (birthday == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(birthday);
		}

		if (password1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(password1);
		}

		if (password2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(password2);
		}

		if (home_phone == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(home_phone);
		}

		if (mobile_phone == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(mobile_phone);
		}

		if (address1 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address1);
		}

		if (address2 == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(address2);
		}

		if (city == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(city);
		}

		if (state == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(state);
		}

		if (zip == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(zip);
		}

		if (security_question == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(security_question);
		}

		if (security_answer == null) {
			objectOutput.writeUTF("");
		}
		else {
			objectOutput.writeUTF(security_answer);
		}
	}

	public long regId;
	public String first_name;
	public String last_name;
	public String email_address;
	public String username;
	public String gender;
	public String birthday;
	public String password1;
	public String password2;
	public String home_phone;
	public String mobile_phone;
	public String address1;
	public String address2;
	public String city;
	public String state;
	public String zip;
	public String security_question;
	public String security_answer;

}