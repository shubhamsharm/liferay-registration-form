/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.model;

import com.liferay.portal.kernel.model.ModelWrapper;
import com.liferay.portal.kernel.model.wrapper.BaseModelWrapper;

import java.util.HashMap;
import java.util.Map;

/**
 * <p>
 * This class is a wrapper for {@link RegistrationForm}.
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see RegistrationForm
 * @generated
 */
public class RegistrationFormWrapper
	extends BaseModelWrapper<RegistrationForm>
	implements ModelWrapper<RegistrationForm>, RegistrationForm {

	public RegistrationFormWrapper(RegistrationForm registrationForm) {
		super(registrationForm);
	}

	@Override
	public Map<String, Object> getModelAttributes() {
		Map<String, Object> attributes = new HashMap<String, Object>();

		attributes.put("regId", getRegId());
		attributes.put("first_name", getFirst_name());
		attributes.put("last_name", getLast_name());
		attributes.put("email_address", getEmail_address());
		attributes.put("username", getUsername());
		attributes.put("gender", getGender());
		attributes.put("birthday", getBirthday());
		attributes.put("password1", getPassword1());
		attributes.put("password2", getPassword2());
		attributes.put("home_phone", getHome_phone());
		attributes.put("mobile_phone", getMobile_phone());
		attributes.put("address1", getAddress1());
		attributes.put("address2", getAddress2());
		attributes.put("city", getCity());
		attributes.put("state", getState());
		attributes.put("zip", getZip());
		attributes.put("security_question", getSecurity_question());
		attributes.put("security_answer", getSecurity_answer());

		return attributes;
	}

	@Override
	public void setModelAttributes(Map<String, Object> attributes) {
		Long regId = (Long)attributes.get("regId");

		if (regId != null) {
			setRegId(regId);
		}

		String first_name = (String)attributes.get("first_name");

		if (first_name != null) {
			setFirst_name(first_name);
		}

		String last_name = (String)attributes.get("last_name");

		if (last_name != null) {
			setLast_name(last_name);
		}

		String email_address = (String)attributes.get("email_address");

		if (email_address != null) {
			setEmail_address(email_address);
		}

		String username = (String)attributes.get("username");

		if (username != null) {
			setUsername(username);
		}

		String gender = (String)attributes.get("gender");

		if (gender != null) {
			setGender(gender);
		}

		String birthday = (String)attributes.get("birthday");

		if (birthday != null) {
			setBirthday(birthday);
		}

		String password1 = (String)attributes.get("password1");

		if (password1 != null) {
			setPassword1(password1);
		}

		String password2 = (String)attributes.get("password2");

		if (password2 != null) {
			setPassword2(password2);
		}

		String home_phone = (String)attributes.get("home_phone");

		if (home_phone != null) {
			setHome_phone(home_phone);
		}

		String mobile_phone = (String)attributes.get("mobile_phone");

		if (mobile_phone != null) {
			setMobile_phone(mobile_phone);
		}

		String address1 = (String)attributes.get("address1");

		if (address1 != null) {
			setAddress1(address1);
		}

		String address2 = (String)attributes.get("address2");

		if (address2 != null) {
			setAddress2(address2);
		}

		String city = (String)attributes.get("city");

		if (city != null) {
			setCity(city);
		}

		String state = (String)attributes.get("state");

		if (state != null) {
			setState(state);
		}

		String zip = (String)attributes.get("zip");

		if (zip != null) {
			setZip(zip);
		}

		String security_question = (String)attributes.get("security_question");

		if (security_question != null) {
			setSecurity_question(security_question);
		}

		String security_answer = (String)attributes.get("security_answer");

		if (security_answer != null) {
			setSecurity_answer(security_answer);
		}
	}

	/**
	 * Returns the address1 of this registration form.
	 *
	 * @return the address1 of this registration form
	 */
	@Override
	public String getAddress1() {
		return model.getAddress1();
	}

	/**
	 * Returns the address2 of this registration form.
	 *
	 * @return the address2 of this registration form
	 */
	@Override
	public String getAddress2() {
		return model.getAddress2();
	}

	/**
	 * Returns the birthday of this registration form.
	 *
	 * @return the birthday of this registration form
	 */
	@Override
	public String getBirthday() {
		return model.getBirthday();
	}

	/**
	 * Returns the city of this registration form.
	 *
	 * @return the city of this registration form
	 */
	@Override
	public String getCity() {
		return model.getCity();
	}

	/**
	 * Returns the email_address of this registration form.
	 *
	 * @return the email_address of this registration form
	 */
	@Override
	public String getEmail_address() {
		return model.getEmail_address();
	}

	/**
	 * Returns the first_name of this registration form.
	 *
	 * @return the first_name of this registration form
	 */
	@Override
	public String getFirst_name() {
		return model.getFirst_name();
	}

	/**
	 * Returns the gender of this registration form.
	 *
	 * @return the gender of this registration form
	 */
	@Override
	public String getGender() {
		return model.getGender();
	}

	/**
	 * Returns the home_phone of this registration form.
	 *
	 * @return the home_phone of this registration form
	 */
	@Override
	public String getHome_phone() {
		return model.getHome_phone();
	}

	/**
	 * Returns the last_name of this registration form.
	 *
	 * @return the last_name of this registration form
	 */
	@Override
	public String getLast_name() {
		return model.getLast_name();
	}

	/**
	 * Returns the mobile_phone of this registration form.
	 *
	 * @return the mobile_phone of this registration form
	 */
	@Override
	public String getMobile_phone() {
		return model.getMobile_phone();
	}

	/**
	 * Returns the password1 of this registration form.
	 *
	 * @return the password1 of this registration form
	 */
	@Override
	public String getPassword1() {
		return model.getPassword1();
	}

	/**
	 * Returns the password2 of this registration form.
	 *
	 * @return the password2 of this registration form
	 */
	@Override
	public String getPassword2() {
		return model.getPassword2();
	}

	/**
	 * Returns the primary key of this registration form.
	 *
	 * @return the primary key of this registration form
	 */
	@Override
	public long getPrimaryKey() {
		return model.getPrimaryKey();
	}

	/**
	 * Returns the reg ID of this registration form.
	 *
	 * @return the reg ID of this registration form
	 */
	@Override
	public long getRegId() {
		return model.getRegId();
	}

	/**
	 * Returns the security_answer of this registration form.
	 *
	 * @return the security_answer of this registration form
	 */
	@Override
	public String getSecurity_answer() {
		return model.getSecurity_answer();
	}

	/**
	 * Returns the security_question of this registration form.
	 *
	 * @return the security_question of this registration form
	 */
	@Override
	public String getSecurity_question() {
		return model.getSecurity_question();
	}

	/**
	 * Returns the state of this registration form.
	 *
	 * @return the state of this registration form
	 */
	@Override
	public String getState() {
		return model.getState();
	}

	/**
	 * Returns the username of this registration form.
	 *
	 * @return the username of this registration form
	 */
	@Override
	public String getUsername() {
		return model.getUsername();
	}

	/**
	 * Returns the zip of this registration form.
	 *
	 * @return the zip of this registration form
	 */
	@Override
	public String getZip() {
		return model.getZip();
	}

	@Override
	public void persist() {
		model.persist();
	}

	/**
	 * Sets the address1 of this registration form.
	 *
	 * @param address1 the address1 of this registration form
	 */
	@Override
	public void setAddress1(String address1) {
		model.setAddress1(address1);
	}

	/**
	 * Sets the address2 of this registration form.
	 *
	 * @param address2 the address2 of this registration form
	 */
	@Override
	public void setAddress2(String address2) {
		model.setAddress2(address2);
	}

	/**
	 * Sets the birthday of this registration form.
	 *
	 * @param birthday the birthday of this registration form
	 */
	@Override
	public void setBirthday(String birthday) {
		model.setBirthday(birthday);
	}

	/**
	 * Sets the city of this registration form.
	 *
	 * @param city the city of this registration form
	 */
	@Override
	public void setCity(String city) {
		model.setCity(city);
	}

	/**
	 * Sets the email_address of this registration form.
	 *
	 * @param email_address the email_address of this registration form
	 */
	@Override
	public void setEmail_address(String email_address) {
		model.setEmail_address(email_address);
	}

	/**
	 * Sets the first_name of this registration form.
	 *
	 * @param first_name the first_name of this registration form
	 */
	@Override
	public void setFirst_name(String first_name) {
		model.setFirst_name(first_name);
	}

	/**
	 * Sets the gender of this registration form.
	 *
	 * @param gender the gender of this registration form
	 */
	@Override
	public void setGender(String gender) {
		model.setGender(gender);
	}

	/**
	 * Sets the home_phone of this registration form.
	 *
	 * @param home_phone the home_phone of this registration form
	 */
	@Override
	public void setHome_phone(String home_phone) {
		model.setHome_phone(home_phone);
	}

	/**
	 * Sets the last_name of this registration form.
	 *
	 * @param last_name the last_name of this registration form
	 */
	@Override
	public void setLast_name(String last_name) {
		model.setLast_name(last_name);
	}

	/**
	 * Sets the mobile_phone of this registration form.
	 *
	 * @param mobile_phone the mobile_phone of this registration form
	 */
	@Override
	public void setMobile_phone(String mobile_phone) {
		model.setMobile_phone(mobile_phone);
	}

	/**
	 * Sets the password1 of this registration form.
	 *
	 * @param password1 the password1 of this registration form
	 */
	@Override
	public void setPassword1(String password1) {
		model.setPassword1(password1);
	}

	/**
	 * Sets the password2 of this registration form.
	 *
	 * @param password2 the password2 of this registration form
	 */
	@Override
	public void setPassword2(String password2) {
		model.setPassword2(password2);
	}

	/**
	 * Sets the primary key of this registration form.
	 *
	 * @param primaryKey the primary key of this registration form
	 */
	@Override
	public void setPrimaryKey(long primaryKey) {
		model.setPrimaryKey(primaryKey);
	}

	/**
	 * Sets the reg ID of this registration form.
	 *
	 * @param regId the reg ID of this registration form
	 */
	@Override
	public void setRegId(long regId) {
		model.setRegId(regId);
	}

	/**
	 * Sets the security_answer of this registration form.
	 *
	 * @param security_answer the security_answer of this registration form
	 */
	@Override
	public void setSecurity_answer(String security_answer) {
		model.setSecurity_answer(security_answer);
	}

	/**
	 * Sets the security_question of this registration form.
	 *
	 * @param security_question the security_question of this registration form
	 */
	@Override
	public void setSecurity_question(String security_question) {
		model.setSecurity_question(security_question);
	}

	/**
	 * Sets the state of this registration form.
	 *
	 * @param state the state of this registration form
	 */
	@Override
	public void setState(String state) {
		model.setState(state);
	}

	/**
	 * Sets the username of this registration form.
	 *
	 * @param username the username of this registration form
	 */
	@Override
	public void setUsername(String username) {
		model.setUsername(username);
	}

	/**
	 * Sets the zip of this registration form.
	 *
	 * @param zip the zip of this registration form
	 */
	@Override
	public void setZip(String zip) {
		model.setZip(zip);
	}

	@Override
	protected RegistrationFormWrapper wrap(RegistrationForm registrationForm) {
		return new RegistrationFormWrapper(registrationForm);
	}

}