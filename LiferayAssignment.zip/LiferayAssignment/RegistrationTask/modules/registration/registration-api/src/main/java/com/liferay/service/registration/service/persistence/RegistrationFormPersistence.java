/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.service.persistence;

import com.liferay.portal.kernel.service.persistence.BasePersistence;
import com.liferay.service.registration.exception.NoSuchRegistrationFormException;
import com.liferay.service.registration.model.RegistrationForm;

import org.osgi.annotation.versioning.ProviderType;

/**
 * The persistence interface for the registration form service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author Brian Wing Shun Chan
 * @see RegistrationFormUtil
 * @generated
 */
@ProviderType
public interface RegistrationFormPersistence
	extends BasePersistence<RegistrationForm> {

	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link RegistrationFormUtil} to access the registration form persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	 * Caches the registration form in the entity cache if it is enabled.
	 *
	 * @param registrationForm the registration form
	 */
	public void cacheResult(RegistrationForm registrationForm);

	/**
	 * Caches the registration forms in the entity cache if it is enabled.
	 *
	 * @param registrationForms the registration forms
	 */
	public void cacheResult(java.util.List<RegistrationForm> registrationForms);

	/**
	 * Creates a new registration form with the primary key. Does not add the registration form to the database.
	 *
	 * @param regId the primary key for the new registration form
	 * @return the new registration form
	 */
	public RegistrationForm create(long regId);

	/**
	 * Removes the registration form with the primary key from the database. Also notifies the appropriate model listeners.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form that was removed
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	public RegistrationForm remove(long regId)
		throws NoSuchRegistrationFormException;

	public RegistrationForm updateImpl(RegistrationForm registrationForm);

	/**
	 * Returns the registration form with the primary key or throws a <code>NoSuchRegistrationFormException</code> if it could not be found.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form
	 * @throws NoSuchRegistrationFormException if a registration form with the primary key could not be found
	 */
	public RegistrationForm findByPrimaryKey(long regId)
		throws NoSuchRegistrationFormException;

	/**
	 * Returns the registration form with the primary key or returns <code>null</code> if it could not be found.
	 *
	 * @param regId the primary key of the registration form
	 * @return the registration form, or <code>null</code> if a registration form with the primary key could not be found
	 */
	public RegistrationForm fetchByPrimaryKey(long regId);

	/**
	 * Returns all the registration forms.
	 *
	 * @return the registration forms
	 */
	public java.util.List<RegistrationForm> findAll();

	/**
	 * Returns a range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @return the range of registration forms
	 */
	public java.util.List<RegistrationForm> findAll(int start, int end);

	/**
	 * Returns an ordered range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @return the ordered range of registration forms
	 */
	public java.util.List<RegistrationForm> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<RegistrationForm>
			orderByComparator);

	/**
	 * Returns an ordered range of all the registration forms.
	 *
	 * <p>
	 * Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to <code>QueryUtil#ALL_POS</code> will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent, then the query will include the default ORDER BY logic from <code>RegistrationFormModelImpl</code>.
	 * </p>
	 *
	 * @param start the lower bound of the range of registration forms
	 * @param end the upper bound of the range of registration forms (not inclusive)
	 * @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	 * @param useFinderCache whether to use the finder cache
	 * @return the ordered range of registration forms
	 */
	public java.util.List<RegistrationForm> findAll(
		int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<RegistrationForm>
			orderByComparator,
		boolean useFinderCache);

	/**
	 * Removes all the registration forms from the database.
	 */
	public void removeAll();

	/**
	 * Returns the number of registration forms.
	 *
	 * @return the number of registration forms
	 */
	public int countAll();

}