/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.service;

import com.liferay.portal.kernel.service.ServiceWrapper;

/**
 * Provides a wrapper for {@link RegistrationFormService}.
 *
 * @author Brian Wing Shun Chan
 * @see RegistrationFormService
 * @generated
 */
public class RegistrationFormServiceWrapper
	implements RegistrationFormService,
			   ServiceWrapper<RegistrationFormService> {

	public RegistrationFormServiceWrapper(
		RegistrationFormService registrationFormService) {

		_registrationFormService = registrationFormService;
	}

	/**
	 * Returns the OSGi service identifier.
	 *
	 * @return the OSGi service identifier
	 */
	@Override
	public String getOSGiServiceIdentifier() {
		return _registrationFormService.getOSGiServiceIdentifier();
	}

	@Override
	public RegistrationFormService getWrappedService() {
		return _registrationFormService;
	}

	@Override
	public void setWrappedService(
		RegistrationFormService registrationFormService) {

		_registrationFormService = registrationFormService;
	}

	private RegistrationFormService _registrationFormService;

}