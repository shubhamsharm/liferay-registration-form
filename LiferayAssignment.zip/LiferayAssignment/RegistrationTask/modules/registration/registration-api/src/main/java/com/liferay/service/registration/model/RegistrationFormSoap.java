/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.liferay.service.registration.model;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.liferay.service.registration.service.http.RegistrationFormServiceSoap}.
 *
 * @author Brian Wing Shun Chan
 * @deprecated As of Athanasius (7.3.x), with no direct replacement
 * @generated
 */
@Deprecated
public class RegistrationFormSoap implements Serializable {

	public static RegistrationFormSoap toSoapModel(RegistrationForm model) {
		RegistrationFormSoap soapModel = new RegistrationFormSoap();

		soapModel.setRegId(model.getRegId());
		soapModel.setFirst_name(model.getFirst_name());
		soapModel.setLast_name(model.getLast_name());
		soapModel.setEmail_address(model.getEmail_address());
		soapModel.setUsername(model.getUsername());
		soapModel.setGender(model.getGender());
		soapModel.setBirthday(model.getBirthday());
		soapModel.setPassword1(model.getPassword1());
		soapModel.setPassword2(model.getPassword2());
		soapModel.setHome_phone(model.getHome_phone());
		soapModel.setMobile_phone(model.getMobile_phone());
		soapModel.setAddress1(model.getAddress1());
		soapModel.setAddress2(model.getAddress2());
		soapModel.setCity(model.getCity());
		soapModel.setState(model.getState());
		soapModel.setZip(model.getZip());
		soapModel.setSecurity_question(model.getSecurity_question());
		soapModel.setSecurity_answer(model.getSecurity_answer());

		return soapModel;
	}

	public static RegistrationFormSoap[] toSoapModels(
		RegistrationForm[] models) {

		RegistrationFormSoap[] soapModels =
			new RegistrationFormSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static RegistrationFormSoap[][] toSoapModels(
		RegistrationForm[][] models) {

		RegistrationFormSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels =
				new RegistrationFormSoap[models.length][models[0].length];
		}
		else {
			soapModels = new RegistrationFormSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static RegistrationFormSoap[] toSoapModels(
		List<RegistrationForm> models) {

		List<RegistrationFormSoap> soapModels =
			new ArrayList<RegistrationFormSoap>(models.size());

		for (RegistrationForm model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new RegistrationFormSoap[soapModels.size()]);
	}

	public RegistrationFormSoap() {
	}

	public long getPrimaryKey() {
		return _regId;
	}

	public void setPrimaryKey(long pk) {
		setRegId(pk);
	}

	public long getRegId() {
		return _regId;
	}

	public void setRegId(long regId) {
		_regId = regId;
	}

	public String getFirst_name() {
		return _first_name;
	}

	public void setFirst_name(String first_name) {
		_first_name = first_name;
	}

	public String getLast_name() {
		return _last_name;
	}

	public void setLast_name(String last_name) {
		_last_name = last_name;
	}

	public String getEmail_address() {
		return _email_address;
	}

	public void setEmail_address(String email_address) {
		_email_address = email_address;
	}

	public String getUsername() {
		return _username;
	}

	public void setUsername(String username) {
		_username = username;
	}

	public String getGender() {
		return _gender;
	}

	public void setGender(String gender) {
		_gender = gender;
	}

	public String getBirthday() {
		return _birthday;
	}

	public void setBirthday(String birthday) {
		_birthday = birthday;
	}

	public String getPassword1() {
		return _password1;
	}

	public void setPassword1(String password1) {
		_password1 = password1;
	}

	public String getPassword2() {
		return _password2;
	}

	public void setPassword2(String password2) {
		_password2 = password2;
	}

	public String getHome_phone() {
		return _home_phone;
	}

	public void setHome_phone(String home_phone) {
		_home_phone = home_phone;
	}

	public String getMobile_phone() {
		return _mobile_phone;
	}

	public void setMobile_phone(String mobile_phone) {
		_mobile_phone = mobile_phone;
	}

	public String getAddress1() {
		return _address1;
	}

	public void setAddress1(String address1) {
		_address1 = address1;
	}

	public String getAddress2() {
		return _address2;
	}

	public void setAddress2(String address2) {
		_address2 = address2;
	}

	public String getCity() {
		return _city;
	}

	public void setCity(String city) {
		_city = city;
	}

	public String getState() {
		return _state;
	}

	public void setState(String state) {
		_state = state;
	}

	public String getZip() {
		return _zip;
	}

	public void setZip(String zip) {
		_zip = zip;
	}

	public String getSecurity_question() {
		return _security_question;
	}

	public void setSecurity_question(String security_question) {
		_security_question = security_question;
	}

	public String getSecurity_answer() {
		return _security_answer;
	}

	public void setSecurity_answer(String security_answer) {
		_security_answer = security_answer;
	}

	private long _regId;
	private String _first_name;
	private String _last_name;
	private String _email_address;
	private String _username;
	private String _gender;
	private String _birthday;
	private String _password1;
	private String _password2;
	private String _home_phone;
	private String _mobile_phone;
	private String _address1;
	private String _address2;
	private String _city;
	private String _state;
	private String _zip;
	private String _security_question;
	private String _security_answer;

}